import Dashboard from './component/Dashboard/Dashboard';
import Header from './component/Header/Header';

function App() {
  return (
    <div >
      <Header />
      <Dashboard />
    </div>
  );
}

export default App;
